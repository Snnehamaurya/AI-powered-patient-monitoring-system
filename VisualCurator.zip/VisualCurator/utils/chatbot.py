import re
import random
import streamlit as st

# Medical knowledge database for common conditions
MEDICAL_KNOWLEDGE = {
    "common_cold": {
        "name": "Common Cold",
        "symptoms": ["cough", "runny nose", "sneezing", "sore throat", "congestion", "mild fever", "headache", "body aches"],
        "causes": "Viruses, most commonly rhinoviruses",
        "treatment": "Rest, fluids, over-the-counter medications for symptom relief",
        "when_to_see_doctor": "If symptoms worsen after 10 days, fever above 101.3°F (38.5°C), or if symptoms are severe",
        "prevention": "Frequent handwashing, avoiding close contact with sick people, not touching your face"
    },
    "flu": {
        "name": "Influenza (Flu)",
        "symptoms": ["high fever", "chills", "body aches", "fatigue", "headache", "cough", "sore throat", "runny nose"],
        "causes": "Influenza viruses (typically A or B)",
        "treatment": "Rest, fluids, antiviral medications if prescribed early",
        "when_to_see_doctor": "If experiencing difficulty breathing, persistent fever, severe weakness, or worsening symptoms",
        "prevention": "Annual flu vaccination, good hygiene practices, avoiding close contact with sick individuals"
    },
    "covid19": {
        "name": "COVID-19",
        "symptoms": ["fever", "cough", "shortness of breath", "fatigue", "body aches", "headache", "loss of taste", "loss of smell", "sore throat"],
        "causes": "SARS-CoV-2 virus",
        "treatment": "Rest, fluids, fever reducers, prescribed treatments for severe cases",
        "when_to_see_doctor": "Difficulty breathing, persistent chest pain/pressure, confusion, inability to stay awake, bluish lips or face",
        "prevention": "Vaccination, physical distancing, masks in high-risk situations, good ventilation, hand hygiene"
    },
    "allergies": {
        "name": "Allergies",
        "symptoms": ["sneezing", "itching", "runny nose", "congestion", "watery eyes", "rash", "hives"],
        "causes": "Immune system reaction to allergens like pollen, dust, pet dander, foods",
        "treatment": "Antihistamines, decongestants, nasal steroids, avoiding allergens",
        "when_to_see_doctor": "If symptoms interfere with daily life or if experiencing severe allergic reaction symptoms",
        "prevention": "Allergen avoidance, air filtration, regular cleaning to reduce allergens"
    },
    "hypertension": {
        "name": "Hypertension (High Blood Pressure)",
        "symptoms": ["headache", "shortness of breath", "nosebleeds", "often no symptoms"],
        "causes": "Genetics, age, diet high in sodium, obesity, stress, lack of exercise, other medical conditions",
        "treatment": "Lifestyle changes, medication as prescribed by doctors",
        "when_to_see_doctor": "Regular monitoring, immediate care if BP exceeds 180/120 with symptoms",
        "prevention": "Healthy diet low in sodium, regular exercise, maintain healthy weight, limit alcohol, avoid smoking"
    },
    "diabetes": {
        "name": "Diabetes",
        "symptoms": ["excessive thirst", "frequent urination", "hunger", "fatigue", "blurred vision", "slow-healing sores"],
        "causes": "Type 1: Immune system attacks insulin-producing cells; Type 2: Cells become resistant to insulin",
        "treatment": "Blood sugar monitoring, insulin therapy, oral medications, diet, exercise",
        "when_to_see_doctor": "If experiencing persistent symptoms or known diabetics with blood sugar outside target range",
        "prevention": "Type 2: Healthy weight, regular exercise, balanced diet; Type 1: Not currently preventable"
    },
    "anxiety": {
        "name": "Anxiety Disorders",
        "symptoms": ["excessive worry", "restlessness", "fatigue", "difficulty concentrating", "irritability", "muscle tension", "sleep problems"],
        "causes": "Genetics, brain chemistry, personality, life events, stress",
        "treatment": "Psychotherapy, medication, stress management techniques",
        "when_to_see_doctor": "When anxiety interferes with daily activities or causes significant distress",
        "prevention": "Stress management, regular exercise, healthy sleep habits, limiting caffeine and alcohol"
    },
    "migraine": {
        "name": "Migraine",
        "symptoms": ["severe headache", "throbbing pain", "nausea", "vomiting", "sensitivity to light", "sensitivity to sound"],
        "causes": "Genetic and environmental factors, hormonal changes, certain foods, stress, sensory stimuli",
        "treatment": "Pain relievers, preventive medications, rest in dark quiet room",
        "when_to_see_doctor": "Severe headaches that don't respond to over-the-counter treatment, or new pattern of headaches",
        "prevention": "Identify and avoid triggers, maintain regular sleep schedule, manage stress, preventive medications"
    },
    "strep_throat": {
        "name": "Strep Throat",
        "symptoms": ["sore throat", "painful swallowing", "fever", "red and swollen tonsils", "small red spots on roof of mouth", "swollen lymph nodes"],
        "causes": "Group A Streptococcus bacteria",
        "treatment": "Antibiotics, rest, fluids, pain relievers",
        "when_to_see_doctor": "Sore throat with fever, swollen lymph nodes, no cough or cold symptoms",
        "prevention": "Regular handwashing, avoid sharing utensils or drinks, replace toothbrush after illness"
    },
    "bronchitis": {
        "name": "Bronchitis",
        "symptoms": ["persistent cough", "mucus production", "fatigue", "shortness of breath", "mild fever", "chest discomfort"],
        "causes": "Viral infection, bacteria (less common), irritants like smoke or pollution",
        "treatment": "Rest, fluids, over-the-counter pain relievers, humidifier, antibiotics only if bacterial",
        "when_to_see_doctor": "Cough lasting more than 3 weeks, fever above 100.4°F (38°C), producing discolored mucus, or trouble breathing",
        "prevention": "Avoid smoking, get vaccinated for flu and pneumonia, wash hands frequently"
    },
    "gastroenteritis": {
        "name": "Gastroenteritis (Stomach Flu)",
        "symptoms": ["diarrhea", "nausea", "vomiting", "stomach pain", "cramping", "fever", "headache", "body aches"],
        "causes": "Viruses, bacteria, parasites, or food reactions",
        "treatment": "Fluids, rest, gradual return to normal diet, medication for specific symptoms",
        "when_to_see_doctor": "Signs of dehydration, blood in stool, fever above 102°F (39°C), severe abdominal pain",
        "prevention": "Proper handwashing, food safety, avoid close contact with infected individuals"
    }
}

# Health information database for general health queries
HEALTH_INFO = {
    "heart_rate": {
        "normal_range": "60-100 beats per minute for adults at rest",
        "high": "Tachycardia is a heart rate over 100 beats per minute. Could indicate stress, exercise, fever, anxiety, or certain heart conditions.",
        "low": "Bradycardia is a heart rate below 60 beats per minute. Common in physically active people, but could indicate heart problems."
    },
    "blood_pressure": {
        "normal_range": "Less than 120/80 mmHg",
        "elevated": "Systolic between 120-129 and diastolic less than 80",
        "high_stage1": "Systolic between 130-139 or diastolic between 80-89",
        "high_stage2": "Systolic at least 140 or diastolic at least 90",
        "crisis": "Systolic over 180 and/or diastolic over 120"
    },
    "oxygen_saturation": {
        "normal_range": "95-100%",
        "concerning": "Below 95% may indicate a health issue",
        "emergency": "Below 90% is a medical emergency requiring immediate attention"
    },
    "temperature": {
        "normal_range": "97.7-99.5°F (36.5-37.5°C)",
        "fever": "Above 100.4°F (38°C)",
        "high_fever": "Above 103°F (39.4°C)"
    },
    "lifestyle": {
        "exercise": "Adults should aim for at least 150 minutes of moderate aerobic activity or 75 minutes of vigorous activity weekly, plus muscle-strengthening activities twice weekly.",
        "diet": "A healthy diet includes vegetables, fruits, whole grains, lean protein, and healthy fats, while limiting sodium, added sugars, and saturated fats.",
        "sleep": "Adults typically need 7-9 hours of sleep per night. Consistent sleep schedule and good sleep environment are important.",
        "stress": "Chronic stress can contribute to health problems. Stress management techniques include mindfulness, exercise, social connection, and setting boundaries."
    }
}

# Common symptom combinations and what they might indicate
SYMPTOM_PATTERNS = {
    ("headache", "fever"): ["Common Cold", "Flu", "COVID-19", "Strep Throat"],
    ("headache", "nausea"): ["Migraine", "Anxiety", "Stomach Flu"],
    ("fever", "cough"): ["Common Cold", "Flu", "COVID-19", "Bronchitis"],
    ("fever", "sore throat"): ["Common Cold", "Flu", "Strep Throat"],
    ("cough", "shortness of breath"): ["COVID-19", "Bronchitis", "Asthma"],
    ("runny nose", "sneezing"): ["Common Cold", "Allergies"],
    ("fatigue", "excessive thirst"): ["Diabetes"],
    ("chest pain", "shortness of breath"): ["Heart Attack", "Anxiety", "COVID-19"],
    ("diarrhea", "vomiting"): ["Stomach Flu", "Food Poisoning"],
    ("joint pain", "fatigue"): ["Flu", "Arthritis", "Autoimmune disorders"],
    ("dizziness", "nausea"): ["Inner ear problems", "Low blood pressure", "Anxiety"]
}

def get_health_assistant_response(prompt, context=""):
    """
    Get a response from the health assistant using built-in medical knowledge
    
    Args:
        prompt (str): User's question or message
        context (str): Additional context about the patient
        
    Returns:
        str: Health assistant's response
    """
    # Let the user know we're processing
    st.session_state.processing = True
    
    # Convert prompt to lowercase for easier matching
    prompt_lower = prompt.lower()
    
    # Check if it's a greeting or general question
    if re.search(r'\b(hello|hi|hey|greetings)\b', prompt_lower):
        st.session_state.processing = False
        return "Hello! I'm your health assistant. How can I help you today? You can ask me about health conditions, vital signs, or general health information."
    
    # Check if question is about heart rate
    if re.search(r'\b(heart rate|pulse|bpm|beats per minute)\b', prompt_lower):
        info = HEALTH_INFO["heart_rate"]
        st.session_state.processing = False
        return f"Heart rate refers to how many times your heart beats per minute.\n\n" \
               f"Normal range: {info['normal_range']}\n" \
               f"High heart rate: {info['high']}\n" \
               f"Low heart rate: {info['low']}\n\n" \
               f"Many factors can affect heart rate including age, activity level, medication, and stress."
    
    # Check if question is about blood pressure
    if re.search(r'\b(blood pressure|hypertension|bp|systolic|diastolic)\b', prompt_lower):
        info = HEALTH_INFO["blood_pressure"]
        st.session_state.processing = False
        return f"Blood pressure is the force of blood against the walls of arteries.\n\n" \
               f"Normal: {info['normal_range']}\n" \
               f"Elevated: {info['elevated']}\n" \
               f"High Blood Pressure Stage 1: {info['high_stage1']}\n" \
               f"High Blood Pressure Stage 2: {info['high_stage2']}\n" \
               f"Hypertensive Crisis: {info['crisis']} (seek immediate medical attention)\n\n" \
               f"Lifestyle factors that can help manage blood pressure include regular physical activity, healthy diet low in sodium, limiting alcohol, avoiding tobacco, and managing stress."
    
    # Check if question is about oxygen saturation
    if re.search(r'\b(oxygen|o2|saturation|spo2|pulse ox)\b', prompt_lower):
        info = HEALTH_INFO["oxygen_saturation"]
        st.session_state.processing = False
        return f"Oxygen saturation (SpO2) measures the percentage of hemoglobin binding sites in the bloodstream occupied by oxygen.\n\n" \
               f"Normal range: {info['normal_range']}\n" \
               f"Concerning level: {info['concerning']}\n" \
               f"Emergency level: {info['emergency']}\n\n" \
               f"Low oxygen levels may cause shortness of breath, confusion, or bluish discoloration of skin."
    
    # Check if question is about body temperature
    if re.search(r'\b(temperature|fever|celsius|fahrenheit|thermometer)\b', prompt_lower):
        info = HEALTH_INFO["temperature"]
        st.session_state.processing = False
        return f"Body temperature is a measure of the body's ability to generate and get rid of heat.\n\n" \
               f"Normal range: {info['normal_range']}\n" \
               f"Fever: {info['fever']}\n" \
               f"High fever: {info['high_fever']}\n\n" \
               f"Fever is the body's natural response to infection. Rest, fluids, and fever-reducing medication can help manage fever symptoms."
    
    # Check if question is about lifestyle
    if re.search(r'\b(exercise|physical activity|workout|fitness)\b', prompt_lower):
        st.session_state.processing = False
        return f"Exercise recommendations: {HEALTH_INFO['lifestyle']['exercise']}"
    
    if re.search(r'\b(diet|nutrition|food|eating|healthy eating)\b', prompt_lower):
        st.session_state.processing = False
        return f"Healthy diet guidelines: {HEALTH_INFO['lifestyle']['diet']}"
    
    if re.search(r'\b(sleep|insomnia|rest|nap)\b', prompt_lower):
        st.session_state.processing = False
        return f"Sleep recommendations: {HEALTH_INFO['lifestyle']['sleep']}"
    
    if re.search(r'\b(stress|anxiety|relaxation|meditation)\b', prompt_lower):
        st.session_state.processing = False
        return f"Stress management: {HEALTH_INFO['lifestyle']['stress']}"
    
    # Check if question is about a specific condition
    for condition, data in MEDICAL_KNOWLEDGE.items():
        if condition in prompt_lower or data["name"].lower() in prompt_lower:
            st.session_state.processing = False
            return f"**{data['name']}**\n\n" \
                   f"**Common symptoms:** {', '.join(data['symptoms'])}\n\n" \
                   f"**Causes:** {data['causes']}\n\n" \
                   f"**General treatment:** {data['treatment']}\n\n" \
                   f"**When to see a doctor:** {data['when_to_see_doctor']}\n\n" \
                   f"**Prevention:** {data['prevention']}\n\n" \
                   f"*Note: This information is for educational purposes only and should not substitute professional medical advice.*"
    
    # If nothing specific matched, provide a general response
    general_responses = [
        "I can provide information about common health conditions, interpret vital signs, or offer general health guidance. Could you be more specific about what you'd like to know?",
        "I'm here to help with health-related questions. I can discuss common conditions, vital signs, or general wellness advice. What specific information are you looking for?",
        "I'd be happy to assist with your health questions. I can explain medical terms, discuss common conditions, or provide general wellness information. Could you clarify what you're interested in?"
    ]
    
    # Extract patient info from context if available
    patient_info = ""
    if context:
        patient_info = "Based on the information provided, please consult with a healthcare provider for personalized advice tailored to your specific situation."
    
    st.session_state.processing = False
    return random.choice(general_responses) + "\n\n" + patient_info

def analyze_symptoms(symptoms_list, patient_context=""):
    """
    Analyze a list of symptoms and suggest possible conditions using built-in medical knowledge
    
    Args:
        symptoms_list (list): List of symptoms reported by the patient
        patient_context (str): Additional context about the patient
        
    Returns:
        str: Analysis of symptoms and possible conditions
    """
    # Let the user know we're processing
    st.session_state.processing = True
    
    # Clean the symptoms (remove duplicates, normalize)
    clean_symptoms = [s.lower().strip() for s in symptoms_list]
    clean_symptoms = list(set(clean_symptoms))  # Remove duplicates
    
    # Find matching conditions from our knowledge base
    possible_conditions = []
    matching_severity = {}
    
    # Direct symptom matching with our database
    for condition, data in MEDICAL_KNOWLEDGE.items():
        matches = 0
        for symptom in clean_symptoms:
            if symptom in data["symptoms"]:
                matches += 1
        
        # Calculate match percentage
        if matches > 0:
            match_percentage = matches / len(clean_symptoms) * 100
            if match_percentage >= 30:  # At least 30% match
                possible_conditions.append(data["name"])
                matching_severity[data["name"]] = match_percentage
    
    # Check for known symptom combinations
    for symptom_combo, conditions in SYMPTOM_PATTERNS.items():
        if all(symptom in clean_symptoms for symptom in symptom_combo):
            for condition in conditions:
                if condition not in possible_conditions:
                    possible_conditions.append(condition)
                    matching_severity[condition] = 70  # Default match percentage for pattern matches
    
    # Construct the response
    if possible_conditions:
        # Sort conditions by match percentage (descending)
        sorted_conditions = sorted(possible_conditions, key=lambda x: matching_severity.get(x, 0), reverse=True)
        
        response = f"Based on the symptoms you've described ({', '.join(clean_symptoms)}), here's some information:\n\n"
        
        response += "**Possible conditions to discuss with your healthcare provider:**\n"
        for i, condition in enumerate(sorted_conditions[:5]):  # Limit to top 5
            response += f"- {condition}\n"
        
        response += "\n**When to seek medical attention:**\n"
        response += "- If symptoms are severe or rapidly worsening\n"
        response += "- If you have difficulty breathing or chest pain\n"
        response += "- If you have high fever that doesn't respond to medication\n"
        response += "- If symptoms persist for more than a few days without improvement\n"
        
        response += "\n**General self-care suggestions:**\n"
        response += "- Rest and stay hydrated\n"
        response += "- Over-the-counter pain relievers may help with discomfort\n"
        response += "- Avoid strenuous activities while recovering\n"
        response += "- Monitor your symptoms and track any changes\n"
        
        response += "\n**IMPORTANT DISCLAIMER:**\n"
        response += "*This information is provided for educational purposes only and is not a medical diagnosis. " \
                   "The analysis is based on general patterns and should not replace professional medical advice. " \
                   "Always consult with a qualified healthcare provider for proper diagnosis and treatment.*"
    else:
        response = f"I don't have enough information to suggest possible conditions based on the symptoms provided ({', '.join(clean_symptoms)}).\n\n" \
                   "For a better assessment, please:\n" \
                   "- Provide more specific symptoms\n" \
                   "- Include details like duration, severity, and any other related symptoms\n\n" \
                   "If you're experiencing concerning symptoms, it's always best to consult with a healthcare professional for proper evaluation."
    
    st.session_state.processing = False
    return response