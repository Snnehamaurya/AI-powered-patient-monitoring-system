import streamlit as st
import pandas as pd
from utils.chatbot import analyze_symptoms, get_health_assistant_response

# List of common symptoms organized by body systems
COMMON_SYMPTOMS = {
    "General": [
        "Fever", "Fatigue", "Weight loss", "Weight gain", "Night sweats", 
        "Weakness", "Malaise", "Chills"
    ],
    "Head & Neurological": [
        "Headache", "Dizziness", "Confusion", "Memory problems", "Seizures",
        "Fainting", "Numbness", "Tingling", "Tremors", "Balance problems"
    ],
    "Eyes": [
        "Blurred vision", "Double vision", "Eye pain", "Eye redness",
        "Vision loss", "Sensitivity to light", "Eye discharge"
    ],
    "Ears, Nose & Throat": [
        "Ear pain", "Hearing loss", "Ringing in ears", "Runny nose",
        "Nasal congestion", "Sore throat", "Hoarseness", "Difficulty swallowing",
        "Mouth sores", "Toothache", "Bleeding gums", "Bad breath"
    ],
    "Respiratory": [
        "Shortness of breath", "Cough", "Wheezing", "Chest pain", 
        "Coughing up blood", "Excessive sputum", "Rapid breathing"
    ],
    "Cardiovascular": [
        "Chest pain", "Palpitations", "Rapid heartbeat", "Slow heartbeat",
        "High blood pressure", "Low blood pressure", "Swelling in legs or feet"
    ],
    "Gastrointestinal": [
        "Abdominal pain", "Nausea", "Vomiting", "Diarrhea", "Constipation",
        "Blood in stool", "Black stool", "Heartburn", "Bloating", "Gas",
        "Loss of appetite", "Increased appetite", "Difficulty swallowing"
    ],
    "Urinary": [
        "Painful urination", "Frequent urination", "Urgent urination",
        "Blood in urine", "Dark urine", "Decreased urine output", 
        "Incontinence", "Flank pain"
    ],
    "Skin": [
        "Rash", "Itching", "Hives", "Blisters", "Skin discoloration",
        "Skin dryness", "Excessive sweating", "Hair loss", "Nail changes"
    ],
    "Musculoskeletal": [
        "Joint pain", "Muscle pain", "Back pain", "Stiffness", "Swelling",
        "Limited range of motion", "Muscle weakness", "Cramps"
    ],
    "Psychological": [
        "Anxiety", "Depression", "Mood swings", "Irritability", "Sleep problems",
        "Hallucinations", "Paranoia", "Suicidal thoughts", "Difficulty concentrating"
    ],
    "Reproductive (Male)": [
        "Testicular pain", "Penile discharge", "Erectile dysfunction", 
        "Prostate problems", "Scrotal swelling"
    ],
    "Reproductive (Female)": [
        "Menstrual irregularities", "Vaginal discharge", "Vaginal bleeding",
        "Breast pain", "Breast lumps", "Hot flashes"
    ]
}

def show_symptom_checker(patient_id):
    """
    Display symptom checker tool for diagnosing potential conditions
    
    Args:
        patient_id (str): ID of the selected patient
    """
    st.title("AI Symptom Analyzer")
    
    # Initialize session state variables
    if "selected_symptoms" not in st.session_state:
        st.session_state.selected_symptoms = []
    
    if "symptom_analysis" not in st.session_state:
        st.session_state.symptom_analysis = None
    
    if "processing" not in st.session_state:
        st.session_state.processing = False
    
    if "error" not in st.session_state:
        st.session_state.error = None
    
    # Get patient info
    patient_info = st.session_state.patients[patient_id]
    patient_data = st.session_state.patient_data[patient_id]
    
    # Generate patient context
    patient_context = f"""
    Patient: {patient_info['name']}
    Age: {patient_info['age']}
    Gender: {patient_info['gender']}
    Medical Condition: {patient_info['condition']}
    """
    
    # Add vital signs if available
    if not patient_data.empty:
        latest = patient_data.iloc[-1]
        patient_context += f"""
        Latest Vital Signs:
        - Heart Rate: {int(latest['heart_rate'])} bpm
        - Blood Pressure: {int(latest['blood_pressure_systolic'])}/{int(latest['blood_pressure_diastolic'])} mmHg
        - Oxygen Saturation: {int(latest['oxygen_saturation'])}%
        - Temperature: {round(latest['temperature'], 1)}°C
        """
    
    # Information about the tool
    with st.expander("About the Symptom Analyzer", expanded=False):
        st.info("""
        This AI-powered tool helps analyze symptoms and suggest possible conditions.
        
        **How to use:**
        1. Select symptoms from the categories provided
        2. Add any additional symptoms not listed
        3. Click 'Analyze Symptoms' to receive an analysis
        
        **Important Note:**
        This tool is for informational purposes only and is not a substitute for 
        professional medical advice, diagnosis, or treatment. Always consult 
        with a qualified healthcare provider for medical concerns.
        """)
    
    # Main layout with two columns
    col1, col2 = st.columns([2, 3])
    
    with col1:
        st.subheader("Select Symptoms")
        
        # Create tabs for symptom categories
        tabs = st.tabs(list(COMMON_SYMPTOMS.keys()))
        
        # Add symptoms from each category
        for i, (category, symptoms) in enumerate(COMMON_SYMPTOMS.items()):
            with tabs[i]:
                for symptom in symptoms:
                    is_selected = symptom in st.session_state.selected_symptoms
                    if st.checkbox(symptom, value=is_selected, key=f"cb_{symptom}"):
                        if symptom not in st.session_state.selected_symptoms:
                            st.session_state.selected_symptoms.append(symptom)
                    elif symptom in st.session_state.selected_symptoms:
                        st.session_state.selected_symptoms.remove(symptom)
        
        # Option to add custom symptoms
        st.markdown("---")
        st.subheader("Add Custom Symptoms")
        custom_symptom = st.text_input("Enter other symptoms not listed above")
        
        if st.button("Add Symptom") and custom_symptom:
            if custom_symptom not in st.session_state.selected_symptoms:
                st.session_state.selected_symptoms.append(custom_symptom)
                st.success(f"Added: {custom_symptom}")
                st.rerun()
    
    with col2:
        st.subheader("Selected Symptoms")
        
        if not st.session_state.selected_symptoms:
            st.info("No symptoms selected yet. Please select symptoms from the left panel.")
        else:
            # Display selected symptoms as pills with remove option
            symptom_cols = st.columns(3)
            for i, symptom in enumerate(sorted(st.session_state.selected_symptoms)):
                with symptom_cols[i % 3]:
                    st.markdown(f"**{symptom}** ❌")
                    if st.button("Remove", key=f"remove_{symptom}"):
                        st.session_state.selected_symptoms.remove(symptom)
                        st.rerun()
        
        # Button to analyze symptoms
        st.markdown("---")
        analyze_button = st.button(
            "Analyze Symptoms", 
            disabled=len(st.session_state.selected_symptoms) == 0 or st.session_state.processing,
            type="primary"
        )
        
        if analyze_button:
            with st.spinner("Analyzing symptoms... This may take a moment."):
                analysis = analyze_symptoms(
                    st.session_state.selected_symptoms,
                    patient_context
                )
                st.session_state.symptom_analysis = analysis
        
        # Display the analysis
        if st.session_state.symptom_analysis:
            st.markdown("---")
            st.subheader("Symptom Analysis")
            st.markdown(st.session_state.symptom_analysis)
            
            # Option to clear analysis
            if st.button("Clear Analysis"):
                st.session_state.symptom_analysis = None
                st.rerun()
            
            # Add to chat option
            if st.button("Continue in Chat Assistant"):
                if "chat_history" not in st.session_state:
                    st.session_state.chat_history = []
                
                # Format symptoms for the chat
                symptom_text = ", ".join(st.session_state.selected_symptoms)
                user_message = f"I have the following symptoms: {symptom_text}. What could be wrong with me?"
                
                # Add to chat history
                st.session_state.chat_history.append({"role": "user", "content": user_message})
                st.session_state.chat_history.append({"role": "assistant", "content": st.session_state.symptom_analysis})
                
                # Switch to the chatbot page by changing the sidebar radio selection
                st.session_state.nav_selection = "Health Assistant"
                st.rerun()
    
    # Button to clear all selected symptoms
    if st.session_state.selected_symptoms:
        if st.button("Clear All Symptoms"):
            st.session_state.selected_symptoms = []
            st.rerun()